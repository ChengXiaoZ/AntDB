# How to contribute #

##Before Submitting an issue##

1. Upgrade to the latest version of pgBadger and see if the problem remains

2. Look at the [closed issues](https://github.com/dalibo/pgbadger/issues?state=closed), we may have already answered a similar problem

3. [Read the doc](http://dalibo.github.com/pgbadger/). It is short and useful.
